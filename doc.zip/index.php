
        <?php
            require "fpdf.php";

            class myPDF extends FPDF{
                function Header(){
                    $this->Image('jan.jpg',10,6,20,20);
                    $this->SetFont('Arial','B',14);
                    $this->Cell(276,5,'COMPANY DOCUMENT',0,0,'C');
                    $this->Ln();
                    $this->SetFont('Times','',12);
                    $this->Cell(276,10,'Eiei',0,0,'C');
                    $this->Ln(20);
                }

                function Footer(){
                    $this->SetY(-15);
                    $this->SetFont('Times','B',12);
                    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
                }

                function HeaderTable(){
                    $this->SetFont('Times','B',12);
                    $this->Cell(130,10,'CompanyName',1,0,'C');
                    $this->Cell(70,10,'OderID',1,0,'C');
                    $this->Cell(70,10,'TotalPrice',1,0,'C');
                    $this->Ln();
                }

            }

            $pdf = new myPDF();
            $pdf->AliasNbPages();
            $pdf->AddPage('L','A4',0);
            $pdf->HeaderTable();
            $pdf->Output();
         ?>
