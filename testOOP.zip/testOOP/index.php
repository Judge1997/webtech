<?php

require 'vendor/autoload.php';
use Judge\Car;
use Judge\RaceCar;
use Judge\Controller\App;
// require 'RaceCar.php';

$car1 = new Car('EiEi','Black');
$car2 = new Car('Kono','Red');
$raceCar1 = new RaceCar('GuLnwMak', 'Gold', 10000000, 1);
// $car1->setName('EiEi');
var_dump(new App());

echo '<br>'.Car::$eiei;
echo '<h1>'.$car1->name.'</h1>';
echo $car1->toString();
echo $raceCar1->toString();
echo "<pre>";
var_dump($car1);
var_dump($car2);
var_dump($raceCar1);
echo "</pre>";

 ?>
