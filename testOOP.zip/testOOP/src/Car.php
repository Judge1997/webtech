<?php
namespace Judge;

class Car{

    var $name;
    protected $color;
    public static $eiei = 'PoomJa';

    function __construct($name,$color){
        $this->name = $name;
        $this->color = $color;
    }

    function getName(){
        return $this->name;
    }

    function setName($name){
        $this->name = $name;
    }

    function toString(){
        return $this->color;
    }

}
 ?>
