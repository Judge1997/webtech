<?php
namespace Judge;
use Judge\Car;

class RaceCar extends Car{

    var $topSpeed;
    var $rank;

    function __construct($name, $color, $topSpeed, $rank){
        $this->name = $name;
        $this->color = $color;
        $this->topSpeed = $topSpeed;
        $this->rank = $rank;
    }

    function getTopSpeed(){
        return $this->topSpeed;
    }

    function setTopSpeed(){
        $this->topSpeed = $topSpeed;
    }

    function toString(){
        return $this->rank;
    }

}
 ?>
