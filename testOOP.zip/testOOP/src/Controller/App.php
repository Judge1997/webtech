<?php
namespace Judge\Controller;

class App{
    
}

 ?>
